--- 
customlog: 
  - 
    format: combined
    target: /usr/local/apache/domlogs/thebennettmethod.com
  - 
    format: "\"%{%s}t %I .\\n%{%s}t %O .\""
    target: /usr/local/apache/domlogs/thebennettmethod.com-bytes_log
documentroot: /home/thebenne/public_html
group: thebenne
hascgi: 1
homedir: /home/thebenne
ifmodulemodsuphpc: 
  group: thebenne
ifmodulemoduserdirc: {}

include: 
  - 
    include: "\"/usr/local/apache/conf/userdata/*.conf\""
  - 
    include: "\"/usr/local/apache/conf/userdata/*.owner-root\""
  - 
    include: "\"/usr/local/apache/conf/userdata/std/*.conf\""
  - 
    include: "\"/usr/local/apache/conf/userdata/std/*.owner-root\""
  - 
    include: "\"/usr/local/apache/conf/userdata/std/2/*.conf\""
  - 
    include: "\"/usr/local/apache/conf/userdata/std/2/*.owner-root\""
ip: 174.121.227.2
owner: root
phpopenbasedirprotect: 1
port: 80
scriptalias: 
  - 
    path: /home/thebenne/public_html/cgi-bin
    url: /cgi-bin/
  - 
    path: /home/thebenne/public_html/cgi-bin/
    url: /cgi-bin/
serveradmin: webmaster@thebennettmethod.com
serveralias: www.thebennettmethod.com
servername: thebennettmethod.com
usecanonicalname: 'Off'
user: thebenne
userdirprotect: ''
