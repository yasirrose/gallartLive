-- cPanel mysql backup
GRANT USAGE ON *.* TO 'thebenne'@'localhost' IDENTIFIED BY PASSWORD '024a04d073059bd6';
GRANT ALL PRIVILEGES ON `thebenne\_meth0d`.* TO 'thebenne'@'localhost';
GRANT ALL PRIVILEGES ON `thebenne\_%`.* TO 'thebenne'@'localhost';
GRANT USAGE ON *.* TO 'thebenne_meth0d'@'localhost' IDENTIFIED BY PASSWORD '644b2c2f64238956';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, REFERENCES, INDEX, ALTER, CREATE TEMPORARY TABLES, LOCK TABLES, EXECUTE, CREATE VIEW, SHOW VIEW, CREATE ROUTINE, ALTER ROUTINE ON `thebenne\_meth0d`.* TO 'thebenne_meth0d'@'localhost';
